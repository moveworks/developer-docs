curl --location --request PATCH 'https://<YOUR_DOMAIN>.my.salesforce.com/services/data/v63.0/sobjects/Opportunity/<OPPORTUNITY_ID>' \--data '{
  "StageName": "<STAGE_NAME>"
}
